const express = require('express'); //Ensure our express framework has been added
const app = express();
const { Pool, pool } = require("./dbConfig");
const bcrypt = require('bcrypt');
const session = require('express-session');
const flash = require('express-flash');
const passport = require('passport');

const PORT = process.env.PORT || 3000;

const initializePassport = require("./passportConfig");
pool.connect();
initializePassport(passport);

// Middleware

var bodyParser = require('body-parser'); //Ensure our body-parser tool has been added
app.use(bodyParser.json());              // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies
app.use(session({
    secret: 'secret',


    resave: false,

    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(flash());


app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/'));//This line is necessary for us to use relative paths and access our resources directory

app.get('/', (req, res) => {
	res.render('pages/index',{
		local_css:"signin.css", 
		my_title:"Index Page"
	});
});

// registration page 
app.get('/register', checkAuthenticated, (req, res) => {
    res.render('pages/register',{
        my_title:"Registration Page"
    });
});

app.get('/login', checkAuthenticated, (req, res) => {
    let {email, password} = req.body;
    console.log({
        email,
        password
    });
    console.log(req.session.flash.error);
	res.render('pages/login',{
		local_css:"signin.css", 
		my_title:"Login Page"
	});
});

app.get('/home', checkNotAuthenticated, (req, res) => {
    console.log(req.isAuthenticated());
    pool.query(
        `SELECT * FROM explorer ORDER BY score DESC`, (err, results)=>{
            if(err){
                throw err;
            }
            console.log(results.rows);
            res.render('pages/home', {
                my_title:"Home page",
                items: results.rows
            });
        }
    );
});

app.get('/user_page', checkNotAuthenticated, (req, res) => {
    res.render('pages/user_page', {
        my_title:"User page",
        username: req.user.explorerid,
        firstname: req.user.firstname,
        lastname: req.user.lastname,
        score: req.user.score,
        location: req.user.usercoordinates,
        bio: req.user.bio,
        explorerimg: req.user.explorerimg
    });
});

app.get('/locationsv2', checkNotAuthenticated, (req, res) => {
    pool.query(
        `SELECT * FROM locations`, (err, results)=>{
            if(err){
                throw err;
            }
            console.log(results.rows);
            res.render('pages/locationsv2', {
                my_title:"Locations page",
                items: results.rows
            });
        }
    );
});

app.get('/locationsub', checkNotAuthenticated, (req, res) => {
    res.render('pages/locationsub', {
        my_title:"Location Sub page"
    });
});

app.get('/about_us', checkNotAuthenticated, (req, res) => {
    res.render('pages/about_us', {
        my_title:"About Us page"
    });
});

app.get('/logout', (req, res) => {
    req.logout();
    res.render('pages/index', {
        local_css:"signin.css",
        my_title:"Index page"
    });
  });

app.post('/locationsv2', async (req, res) => {
    let pointsval = Number(req.body.points);
    console.log(pointsval);
    var score = req.user.score;
    score = score + pointsval;
    pool.query(
        `UPDATE explorer SET score=$1 WHERE email=$2`, [score,req.user.email], (err, results)=>{
            if(err){
                throw err;
            }
        }
    );
    console.log(req.user.score);
    pool.query(
        `SELECT * FROM locations`, (err, results)=>{
            if(err){
                throw err;
            }
            console.log(results.rows);
            res.render('pages/locationsv2', {
                my_title:"Locations page",
                items: results.rows
            });
        }
    );
})

app.post('/register', async (req, res) => {
    let {locationname, pointreward, locationtype, locationimage} = req.body;
    let coordinatesoflocation = 0;
    console.log({
        locationname,
        coordinatesoflocation,
        pointreward,
        locationtype,
        locationimage
    });

    pool.query(
        `INSERT INTO locations (locationname, coordinatesoflocation, pointreward, locationtype, locationimage)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING locationname`, 
            [locationname, coordinatesoflocation, pointreward, locationtype, locationimage],
            (err, results) => {
                if (err){
                    throw err;
                }
                console.log(results.rows);
                res.redirect('/locationsv2');
            }
    );
});

app.post('/register', async (req, res) => {
    let {firstname, lastname, explorerid, email, password, passwordConfirm} = req.body;
    console.log({
        firstname,
        lastname,
        explorerid,
        email,
        password,
        passwordConfirm
    });
    let usercoordinates = 0;
    let score = 0;
    let bio = 'Example Bio';
    let explorerimg = 'https://recap-project.eu/wp-content/uploads/2017/02/default-user.jpg';

    let errors = [];

    if(!firstname || !lastname || ! explorerid || !email || !password || !passwordConfirm){
        errors.push({message: "Please enter all fields"});
    }

    if(password.length < 6) {
        errors.push({message: "Password should be at least 6 characters"});
    }

    if(password != passwordConfirm){
        errors.push({message: "Passwords do not match"});
    }

    if(errors.length > 0){
        res.render("pages/register",{errors});
    }else{
        // Form validated

        //attempt at hashing for security
        let hashedPassword = await bcrypt.hash(password, 10);

        pool.query(
            `SELECT * FROM explorer
            WHERE email = $1 OR explorerid = $2`, [email, explorerid], (err, results)=>{
                if(err){
                    throw err;
                }
                console.log(results.rows);

                if(results.rows.length > 0){
                    errors.push({message: "Email or Username already registered"});
                    res.render('pages/register',{errors});
                } else {
                    pool.query(
                        `INSERT INTO explorer (explorerid, email, password, firstname, lastname, usercoordinates, achievementcoordinates, score, achievementid, challengeid)
                            VALUES ($1, $2, $3, $4, $5, 0, 0, 0, 0, 0)
                            RETURNING explorerid, email, password`, 
                            [explorerid, email, hashedPassword, firstname, lastname],
                            (err, results) => {
                                if (err){
                                    throw err;
                                }
                                console.log(results.rows);
                                req.flash('success_msg',"You are now registered. Please log in.")
                                res.redirect('/login');
                            }
                    );
                }
            }
        );
    }
});

app.post('/login',passport.authenticate("local", {
      successRedirect: '/home',
      failureRedirect: '/login',
      failureFlash: true
    })
  );
  
  function checkAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
      return res.redirect('/home');
    }
    next();
  }
  
  function checkNotAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
      return next();
    }
    res.redirect('/login');
  }

// Start the Express server
app.listen(3000, () => console.log('Server running on port 3000!'))
//app.listen(process.env.PORT);