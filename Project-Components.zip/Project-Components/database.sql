CREATE TABLE IF NOT EXISTS Explorer (
    ExplorerID varchar(255) NOT NULL,
    Email varchar(255) NOT NULL,
    Password varchar(255) NOT NULL,
    FirstName varchar(255) NOT NULL,
    LastName varchar(255) NOT NULL,
    UserCoordinates varchar(255) NOT NULL,
    Score integer NOT NULL,
    Bio varchar(255) NOT NULL,
    ExplorerImg varchar (255) NOT NULL,
    CONSTRAINT Explorer_pk PRIMARY KEY (Email)
);

CREATE TABLE IF NOT EXISTS Locations (
    LocationName varchar(255) NOT NULL,
    CoordinatesOfLocation varchar(255) NOT NULL,
    PointReward int NOT NULL,
    LocationType varchar(255) NOT NULL,
    LocationImage varchar(512) NOT NULL,
    CONSTRAINT Locations_pk PRIMARY KEY (LocationName)
);

INSERT INTO explorer(explorerid, email, password, firstname, lastname, UserCoordinates, score, Bio, ExplorerImg)
VALUES('nfree', 'noah@gmail.com', '$2b$10$cg2UqB./3DbZYEPV3W9r1.8iH9XA0JL19q4tG6ULPUddQqg6aQ9i2', 'Noah', 'Freeland', '0', 1700,'Example Bio','https://recap-project.eu/wp-content/uploads/2017/02/default-user.jpg'),
 ('gorwe', 'george@gmail.com', '$2b$10$D0u1fXti7RM1Y0tWQx35d.qYHaxV/hV0SWr8A1lT9JKVeZxA.KcJq', 'George', 'Orwell', '0', 800,'Example Bio','https://recap-project.eu/wp-content/uploads/2017/02/default-user.jpg'),
 ('mshell', 'mary@gmail.com', '$2b$10$SNRgr5IvadfckvIbVzVKVOtk8L03SXUBs4svUnLL8GMboiCP1INm.', 'Mary', 'Shelly', '0', 400,'Example Bio','https://recap-project.eu/wp-content/uploads/2017/02/default-user.jpg'),
 ('ehemin', 'earnest@gmail.com', '$2b$10$v8ZYaJf8kKRVmLzrIG6dN.M/7xdbp4GEPIjcmLQaimR2SvHGKlcfu', 'Earnest', 'Hemingway', '0', 900,'Example Bio','https://recap-project.eu/wp-content/uploads/2017/02/default-user.jpg');

INSERT INTO locations(locationname, CoordinatesOfLocation, PointReward, LocationType, LocationImage)
VALUES('Winter Park Resort', '0', '100','Ski Resort','https://www.winterparkresort.com/-/media/winter-park/lodging/wp_kr_winter10_wp19-2400x1350.ashx?la=en?h=1350&w=2400&hash=825CC7E966C99D307984A24F3CF98300'),
('Mount Elbert','0','300','14er','https://upload.wikimedia.org/wikipedia/commons/1/1e/Mt._Elbert.jpg'),
('Snowmass Ski Resort','0','100','Ski Resort','https://wallpaperaccess.com/full/911281.jpg'),
('Red Rocks Ampitheatre','0','500','Concert Venue','https://assets.simpleviewinc.com/simpleview/image/upload/c_limit,h_1200,q_75,w_1200/v1/clients/denver/Courtesy_of_Denver_Arts_Venues_photo_by_Stevie_Crecelius_54d857ea-c300-4659-a529-2f9b6c7af129.jpg')
;
